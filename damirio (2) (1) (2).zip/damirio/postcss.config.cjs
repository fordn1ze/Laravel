module.exports = {
    plugins: {
        tailwindcss: {}, // Подключение плагина Tailwind CSS для обработки стилей
        autoprefixer: {}, // Подключение плагина Autoprefixer для добавления вендорных префиксов к CSS свойствам
    },
};
