import laravel from "laravel-vite-plugin"; // Импортируем плагин для интеграции с Laravel
import { defineConfig } from "vite"; // Импортируем функцию defineConfig из Vite
import postcssConfig from "./postcss.config.cjs"; // Импортируем конфигурацию PostCSS

export default defineConfig({
    // Конфигурация сборщика Vite
    plugins: [
        // Используем плагин для интеграции с Laravel
        laravel({
            input: ["resources/css/app.css", "resources/js/app.js"], // Входные точки для сборки
            refresh: true, // Флаг, указывающий на необходимость обновления страницы при изменении файлов
        }),
    ],
    css: {
        postcssConfig, // Используем конфигурацию PostCSS
    },
});
