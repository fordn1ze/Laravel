<div class="flex flex-row items-center justify-between gap-4 flex-wrap bg-white border border-gray-200 shadow-sm rounded-xl p-4 md:p-5 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400">
    <h3 id="newsCountContainer" class="text-2xl font-semibold text-gray-800 dark:text-white">
        Всего товаров: <?php echo e($totalQuantity); ?>

    </h3>
</div>

<div id="newsContentContainer" class="grid lg:grid-cols-2 lg:gap-y-16 gap-10 mt-10">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="group rounded-xl overflow-hidden" href="/catalog/<?php echo e($product->id); ?>">
        <div class="sm:flex">
            <div class="flex-shrink-0 relative rounded-xl overflow-hidden w-full sm:w-56 h-44">
                <img class="group-hover:scale-105 transition-transform duration-500 ease-in-out size-full absolute top-0 start-0 object-cover rounded-xl" src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->title); ?>">
            </div>
            <div class="grow mt-4 sm:mt-0 sm:ms-6 px-4 sm:px-0">
                <h3 class="text-xl font-semibold text-gray-800 group-hover:text-gray-600 dark:text-neutral-300 dark:group-hover:text-white line-clamp-1">
                    <?php echo e($product->title); ?>

                </h3>
                <p class="mt-3 text-gray-600 dark:text-neutral-400 line-clamp-3">
                    <?php echo e($product->description); ?>

                </p>
                <div class="flex flex-row gap-2 items-center justify-between mt-4">
                    <p class="inline-flex items-center gap-x-1 text-blue-600 decoration-2 hover:underline font-medium">
                        Подробнее
                        <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m9 18 6-6-6-6" />
                        </svg>
                    </p>
                    <span class="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-white/10 dark:text-white"><?php echo e($product->price); ?> ₽</span>
                </div>
                <div class="mt-2">
                    <span class="text-xs font-medium text-gray-500">На складе: <?php echo e($product->quantity); ?> шт.</span>
                </div>
            </div>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\OSPanel\home\damirio\resources\views/catalog/page.blade.php ENDPATH**/ ?>