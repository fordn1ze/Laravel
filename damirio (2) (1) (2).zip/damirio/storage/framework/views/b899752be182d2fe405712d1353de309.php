<div class="p-4 overflow-y-auto">
    <form id="reg-form" method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <label for="reg-name" class="block text-sm mb-2 dark:text-white">
            Имя
            <input name="name" type="text" id="reg-name" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите ваше имя" required>
        </label>
        <label for="reg-phone" class="block text-sm mb-2 dark:text-white">
            Телефон
            <input name="phone" type="text" id="reg-phone" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите ваш телефон" required>
        </label>
        <label for="reg-address" class="block text-sm mb-2 dark:text-white">
            Адрес
            <input name="address" type="text" id="reg-address" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите ваш адрес" required>
        </label>
        <label for="reg-email" class="block text-sm mb-2 dark:text-white">
            Почта
            <input name="email" type="text" id="reg-email" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите вашу почту" required>
        </label>
        <label for="hs-toggle-password2" class="block text-sm mb-2 dark:text-white">
            Пароль
            <div class="relative">
                <input name="password" id="hs-toggle-password2" type="password" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Придумайте пароль" autocomplete="new-password" required>
                <button type="button" data-hs-toggle-password='{"target": "#hs-toggle-password2"}' class="absolute top-0 end-0 p-3.5 rounded-e-md">
                    <svg class="flex-shrink-0 size-3.5 text-gray-400" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path class="hs-password-active:hidden" d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path>
                        <path class="hs-password-active:hidden" d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path>
                        <path class="hs-password-active:hidden" d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path>
                        <line class="hs-password-active:hidden" x1="2" x2="22" y1="2" y2="22"></line>
                        <path class="hidden hs-password-active:block" d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
                        <circle class="hidden hs-password-active:block" cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </div>
        </label>
    </form>
    <?php if($errors->any()): ?>
    <div class="flex flex-col gap-2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="inline-flex items-center">
            <span class="size-2 inline-block bg-red-500 rounded-full me-2"></span>
            <span class="text-gray-600 dark:text-neutral-400"><?php echo e($error); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>
<div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t dark:border-neutral-700">
    <button type="button" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-800" data-hs-overlay="#hs-vertically-centered-modal">
        Отмена
    </button>
    <button type="submit" form="reg-form" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
        Зарегестрироваться
    </button>
</div><?php /**PATH C:\OSPanel\home\damirio\resources\views/components/auth/forms/register.blade.php ENDPATH**/ ?>