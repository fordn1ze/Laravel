<?php if(auth()->check()): ?>
<div id="navbar-secondary-content" class="hs-overlay hs-overlay-open:translate-x-0 hidden -translate-x-full fixed top-0 start-0 transition-all duration-300 transform h-full max-w-xs w-full z-[80] bg-white border-e dark:bg-neutral-800 dark:border-neutral-700" tabindex="-1">
    <div class="flex justify-between items-center py-3 px-4 border-b dark:border-neutral-700">
        <h3 class="font-bold text-gray-800 dark:text-white">
            Сообщения
        </h3>
        <button type="button" class="inline-flex flex-shrink-0 justify-center items-center size-8 rounded-lg text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2 focus:ring-offset-white text-sm dark:text-neutral-500 dark:hover:text-neutral-400 dark:focus:ring-neutral-700 dark:focus:ring-offset-gray-800" data-hs-overlay="#navbar-secondary-content">
            <span class="sr-only">Закрыть</span>
            <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 6 6 18" />
                <path d="m6 6 12 12" />
            </svg>
        </button>
    </div>
    <div class="p-4 overflow-y-scroll h-full pb-32 [&::-webkit-scrollbar]:w-2
        [&::-webkit-scrollbar-track]:bg-gray-100
        [&::-webkit-scrollbar-thumb]:bg-gray-300
        dark:[&::-webkit-scrollbar-track]:bg-neutral-700
        dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500">
        <ul class="space-y-5">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($message->recipient_id == Auth::id()): ?>
            <li class="max-w-lg flex flex-col gap-x-2 sm:gap-x-4">
                <div class="bg-white border border-gray-200 rounded-2xl p-4 space-y-3 dark:bg-neutral-900 dark:border-neutral-700">
                    <h2 class="font-medium text-gray-800 dark:text-white">
                        Входящее сообщение от <?php echo e($message->sender ? $message->sender->name : 'системы'); ?>

                    </h2>
                    <div class="space-y-1.5">
                        <p class="text-sm text-gray-800 dark:text-white"><?php echo e($message->message); ?></p>
                    </div>
                </div>
                <div class="ml-2">
                    <span class="text-xs font-medium text-gray-500 dark:text-white"><?php echo e($message->created_at); ?></span>
                </div>
            </li>
            <?php else: ?>
            <li class="max-w-lg ms-auto flex justify-end gap-x-2 sm:gap-x-4">
                <div class="grow text-end">
                    <div class="inline-block bg-blue-600 rounded-2xl p-4 shadow-sm">
                        <p class="text-sm text-white"><?php echo e($message->message); ?></p>
                    </div>
                    <div class="mr-2">
                        <span class="text-xs font-medium text-gray-300"><?php echo e($message->created_at); ?></span>
                    </div>
                </div>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="absolute bottom-0 w-full flex justify-between items-center py-3 px-4 border-t dark:bg-neutral-800 dark:border-neutral-700">
        <button type="button" class="hs-dropdown-toggle w-full py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none" data-hs-overlay="#hs-vertically-centered-modal9" data-hs-overlay-options='{"isClosePrev": false}'>
            Заказать
        </button>
    </div>
</div>

<div id="hs-vertically-centered-modal9" class="hs-overlay hs-overlay-open:opacity-100 hs-overlay-open:duration-500 hidden size-full fixed top-0 start-0 z-[80] opacity-0 overflow-x-hidden transition-all overflow-y-auto pointer-events-none">
    <div class="sm:max-w-lg sm:w-full m-3 sm:mx-auto min-h-[calc(100%-3.5rem)] flex items-center">
        <div class="sm:max-w-lg sm:w-full m-3 sm:mx-auto">
            <div class="w-full flex flex-col bg-white border shadow-sm rounded-xl pointer-events-auto dark:bg-neutral-800 dark:border-neutral-700 dark:shadow-neutral-700/70">
                <div class="flex justify-between items-center py-3 px-4 border-b dark:border-neutral-700">
                    <h3 class="font-bold text-gray-800 dark:text-white">
                        Создание личного заказа
                    </h3>
                    <button type="button" class="flex justify-center items-center size-7 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700" data-hs-overlay="#hs-vertically-centered-modal9">
                        <span class="sr-only">Закрыть</span>
                        <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 6 6 18"></path>
                            <path d="m6 6 12 12"></path>
                        </svg>
                    </button>
                </div>
                <div class="p-4 overflow-y-auto">
                    <form id="cutom-order" action="<?php echo e(route('custom-orders.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="title" class="block text-sm mb-2 dark:text-white">
                            Название товара
                            <input name="title" type="text" id="title" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите название товара" required>
                        </label>
                        <label for="description" class="block text-sm font-medium mb-2 dark:text-white">
                            Описание товара
                            <textarea name="description" id="description" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm focus:border-lime-500 focus:ring-lime-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" rows="3" placeholder="Введите описание товара" required></textarea>
                        </label>
                        <label for="quantity" class="block text-sm mb-2 dark:text-white">
                            Требуемое количество товара
                            <input name="quantity" type="number" id="quantity" class="py-3 px-4 block w-full border border-gray-400 rounded-lg text-sm disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" placeholder="Введите число количества товра" required>
                        </label>
                    </form>
                </div>
                <div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t dark:border-neutral-700">
                    <button type="button" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-800" data-hs-overlay="#hs-vertically-centered-modal9">
                        Отмена
                    </button>
                    <button type="submit" form="cutom-order" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                        Заказть
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH C:\OSPanel\home\damirio\resources\views/components/messages.blade.php ENDPATH**/ ?>