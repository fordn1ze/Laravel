<!DOCTYPE html>
<html class="scroll-smooth dark" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Damirio</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-neutral-900">
    <?php echo $__env->make('main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="max-w-[1440px] mx-auto px-[4vw] mb-8 mt-[70px]">
        <?php echo $__env->make('main.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <?php if(!auth()->check()): ?>
    <?php echo $__env->make('components.auth.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html><?php /**PATH C:\OSPanel\home\damirio\resources\views/main/layout.blade.php ENDPATH**/ ?>