/** @type {import('tailwindcss').Config} */
// Определяем тип конфигурации для Tailwind CSS, используя JSDoc-комментарий

module.exports = {
    // Содержание, которое будет анализироваться Tailwind CSS для генерации стилей
    content: [
        "./resources/**/*.blade.php", // Шаблоны Blade PHP
        "./resources/**/*.js", // JavaScript файлы
        "./resources/**/*.vue", // Файлы Vue.js
        "node_modules/preline/dist/*.js", // Файлы из preline
    ],

    // Режим темной темы (может быть "class" или "media")
    darkMode: "class",

    // Определение пользовательской темы (добавление или переопределение стилей)
    theme: {
        extend: {}, // Расширение существующей темы (добавление пользовательских стилей)
    },

    // Плагины, используемые в конфигурации Tailwind CSS
    plugins: [require("preline/plugin")], // Использование плагина preline
};
