<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class CreateProductsTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('products')) {
            Schema::create('products', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('description');
                $table->decimal('price', 8, 2);
                $table->decimal('shipping_cost', 8, 2)->nullable();
                $table->integer('quantity')->default(0);
                $table->string('image_url')->nullable();
                $table->timestamps();
            });

            DB::table('products')->insert([
                [
                    'title' => 'Apple iPhone 13 Pro',
                    'description' => 'Смартфон с передовой камерой, мощным процессором A15 Bionic и поддержкой 5G.',
                    'price' => 109990,
                    'shipping_cost' => 2500,
                    'quantity' => 150,
                    'image_url' => 'https://msk-apple.ru/image/cache/catalog/Add/13%20pro%20max/30059051bb-700x700.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Dell XPS 15',
                    'description' => 'Ультратонкий ноутбук с процессором Intel Core i7, 16GB RAM и 512GB SSD.',
                    'price' => 159990,
                    'shipping_cost' => 3000,
                    'quantity' => 80,
                    'image_url' => 'https://www.notebookcheck-ru.com/uploads/tx_nbc2/feature.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Sony WH-1000XM4',
                    'description' => 'Беспроводные наушники с активным шумоподавлением и до 30 часов работы.',
                    'price' => 29990,
                    'shipping_cost' => 1000,
                    'quantity' => 200,
                    'image_url' => 'https://doctorhead.ru/upload/resize_cache/webp/iblock/52f/Sony_WH_1000XM4_s6.webp',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Apple Watch Series 7',
                    'description' => 'Умные часы с функциями мониторинга здоровья, GPS и защитой от воды.',
                    'price' => 35990,
                    'shipping_cost' => 1500,
                    'quantity' => 120,
                    'image_url' => 'https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111909_series7-480.png',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Sony PlayStation 5',
                    'description' => 'Игровая консоль нового поколения с поддержкой 4K и VR.',
                    'price' => 54990,
                    'shipping_cost' => 2000,
                    'quantity' => 60,
                    'image_url' => 'https://main-cdn.sbermegamarket.ru/big1/hlr-system/198/819/494/611/960/100061738347b0.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Kindle Paperwhite',
                    'description' => 'Электронная книга с подсветкой экрана и большим объёмом памяти.',
                    'price' => 11990,
                    'shipping_cost' => 500,
                    'quantity' => 100,
                    'image_url' => 'https://static.insales-cdn.com/r/rAB20QsYJX4/rs:fit:1000:0:1/q:100/plain/images/products/1/652/550281868/716TVpWR__L._AC_SL1000_.jpg@jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Samsung 65" QLED 4K TV',
                    'description' => 'Сверхчеткий телевизор с большим экраном и поддержкой всех современных форматов.',
                    'price' => 149990,
                    'shipping_cost' => 3500,
                    'quantity' => 40,
                    'image_url' => 'https://images.samsung.com/is/image/samsung/p6pim/ru/qe65q70cauxru/gallery/ru-qled-q70c-qe65q70cauxru-536582323?$650_519_PNG$',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'JBL Flip 5',
                    'description' => 'Портативная колонка с мощным звуком и водонепроницаемым корпусом.',
                    'price' => 7990,
                    'shipping_cost' => 800,
                    'quantity' => 90,
                    'image_url' => 'https://static.insales-cdn.com/images/products/1/7074/470883234/0004782_jbl_flip5_black_2-1.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'GoPro HERO9 Black',
                    'description' => 'Экшн-камера с возможностью записи видео в 5K и стабилизацией изображения.',
                    'price' => 39990,
                    'shipping_cost' => 1200,
                    'quantity' => 50,
                    'image_url' => 'https://techcrunch.com/wp-content/uploads/2020/09/119556897_10158045279981919_6599215183113979816_o.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Microsoft Xbox Series X',
                    'description' => 'Мощная игровая консоль с поддержкой 4K и высокой частотой кадров.',
                    'price' => 49990,
                    'shipping_cost' => 2000,
                    'quantity' => 70,
                    'image_url' => 'https://assets.xboxservices.com/assets/fb/d2/fbd2cb56-5c25-414d-9f46-e6a164cdf5be.png?n=XBX_A-BuyBoxBGImage01-D.png',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
            ]);
        }
    }

    public function down()
    {
        Schema::dropIfExists('products');
    }
}
