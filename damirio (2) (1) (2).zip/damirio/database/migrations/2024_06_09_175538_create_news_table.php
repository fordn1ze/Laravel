<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class CreateNewsTable extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('news')) {
            Schema::create('news', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('description');
                $table->string('category');
                $table->string('image_url')->nullable();
                $table->timestamps();
            });

            DB::table('news')->insert([
                [
                    'title' => 'Запуск инновационного гаджета',
                    'description' => 'Мы рады объявить о запуске нашего новейшего гаджета, который обещает революционизировать ваш опыт использования техники. Подробности на нашем сайте.',
                    'category' => 'Продукты',
                    'image_url' => 'https://img.freepik.com/free-photo/modern-office-desk-composition-with-technological-device_23-2147915840.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Обновление линейки ноутбуков',
                    'description' => 'Наши новые модели ноутбуков теперь доступны в продаже. Они обладают улучшенными характеристиками и дизайном.',
                    'category' => 'Продукты',
                    'image_url' => 'https://www.hardwareluxx.de/images/cdn02/uploads/2022/Mar/usable_energies_9a/dell_latitude_5330-00_1920px.png',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Супер скидки на аксессуары',
                    'description' => 'Не упустите возможность купить аксессуары для ваших устройств по специальным ценам. Предложение ограничено.',
                    'category' => 'Акции',
                    'image_url' => 'https://kartinki.pics/uploads/posts/2022-02/1645206025_1-kartinkin-net-p-rasprodazha-kartinki-1.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Новая точка продаж',
                    'description' => 'Наш магазин теперь представлен в новом торговом центре. Приходите за лучшей техникой и консультациями наших специалистов.',
                    'category' => 'Новости компании',
                    'image_url' => 'https://www.mvideoeldorado.ru/fileadmin/user_upload/photobank/magaziny-mvideo-formata-mkompakt/02.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Приглашаем на вебинар',
                    'description' => 'Присоединяйтесь к нашему вебинару, где мы расскажем о последних трендах в мире электронной техники и ответим на все ваши вопросы.',
                    'category' => 'События',
                    'image_url' => 'https://static.treolan.ru/images/news/2022/pixelhue_1.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Пополнение ассортимента умных устройств',
                    'description' => 'В наш магазин поступили новые умные устройства, которые сделают вашу жизнь еще более комфортной и продуктивной.',
                    'category' => 'Ассортимент',
                    'image_url' => 'https://sun9-17.userapi.com/impg/sCzF_I7CbqaoUqRZZq3MV1IPQ3S7EdFtnSyLNw/b6uyPkyWvKg.jpg?size=807x807&quality=95&sign=2b5a0d2383257100dbd690e6786f3c82&c_uniq_tag=9ot4Y_4tnYK2dyTTKkgqRcsNHF0jfVkKRNTfGSopPWA&type=album',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Новые поступления летних гаджетов',
                    'description' => 'Лето уже близко, и мы рады представить новые гаджеты для активного отдыха и развлечений. Спешите ознакомиться с нашим ассортиментом!',
                    'category' => 'Ассортимент',
                    'image_url' => 'https://rg.ru/uploads/images/2023/07/09/tecno_659.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Рассрочка без переплат',
                    'description' => 'Теперь вы можете приобрести любую технику в нашем магазине в рассрочку без переплат. Подробности у наших консультантов.',
                    'category' => 'Услуги',
                    'image_url' => 'https://aroma-group.ru/upload/iblock/75a/6kag2o5qhe3wz1nu2ssp1mdr77xb0bq7/Prezentatsiya-Microsoft-PowerPoint-11.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Изменение времени работы в праздники',
                    'description' => 'Уважаемые клиенты, обращаем ваше внимание на изменение графика работы нашего магазина в праздничные дни.',
                    'category' => 'Новости компании',
                    'image_url' => 'https://site-302041.mozfiles.com/files/302041/objavlenie.jpg',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
                [
                    'title' => 'Экспресс-доставка по городу',
                    'description' => 'Воспользуйтесь нашей новой услугой экспресс-доставки по городу. Ваш заказ будет у вас в течение нескольких часов.',
                    'category' => 'Услуги',
                    'image_url' => 'https://static.mvideo.ru/media/Promotions/Promo_Page/2023/August/bystraya-dostavka/img/banner-mob.png',
                    'created_at' => now(),
                    'updated_at' => now()
                ],
            ]);
        }
    }

    public function down()
    {
        Schema::dropIfExists('news');
    }
}
