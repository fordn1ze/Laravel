<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Применение миграции.
     *
     * Создает таблицу заказов, если она отсутствует, и определяет связи с таблицами пользователей и продуктов.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('orders')) {
            Schema::create('orders', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id');
                $table->unsignedBigInteger('product_id');
                $table->integer('quantity');
                $table->string('status')->default('pending');
                $table->timestamps();

                // Определяем внешние ключи для связей с таблицами пользователей и продуктов
                $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
                $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
            });
        }
    }

    /**
     * Отмена миграции.
     *
     * Удаляет таблицу заказов, если она существует.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
