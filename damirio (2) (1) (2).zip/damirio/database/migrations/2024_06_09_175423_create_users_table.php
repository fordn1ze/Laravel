<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class CreateUsersTable extends Migration
{
    /**
     * Применение миграции.
     *
     * Создает таблицу пользователей и вставляет начальные данные, если таблица отсутствует.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('users')) {
            Schema::create('users', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('phone')->unique();
                $table->string('email')->unique();
                $table->string('password');
                $table->string('address');
                $table->enum('role', ['admin', 'user', 'blocked'])->default('user');
                $table->timestamps();
            });

            // Вставляем начального суперадминистратора, если таблица была создана. Можно было использовать seeder, но ты решил тут.
            DB::table('users')->insert([
                'name' => 'SuperAdmin',
                'phone' => '0987654321',
                'email' => 'superadmin@example.com',
                'password' => Hash::make('SuperSecure789'), // Хешируем пароль
                'address' => '123 Admin Blvd, Admin City, Adminland',
                'role' => 'admin',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    /**
     * Отмена миграции.
     *
     * Удаляет таблицу пользователей, если она существует.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
