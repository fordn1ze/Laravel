<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeProductIdToNullableInOrdersTable extends Migration
{
    /**
     * Применение миграции.
     *
     * Изменяет столбец product_id в таблице orders на nullable.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasTable('orders')) {
            Schema::table('orders', function (Blueprint $table) {
                $table->unsignedBigInteger('product_id')->nullable()->change(); // Изменение столбца на nullable
            });
        }
    }

    /**
     * Отмена миграции.
     *
     * Отменяет изменение столбца product_id в таблице orders, удаляя nullable.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->unsignedBigInteger('product_id')->change(); // Удаление nullable
        });
    }
}
