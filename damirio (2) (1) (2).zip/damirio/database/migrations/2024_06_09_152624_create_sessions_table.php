<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Применение миграции.
     *
     * Создает таблицу для хранения сеансов пользователей.
     *
     * @return void
     */
    public function up(): void
    {
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary(); // Уникальный идентификатор сеанса, используемый как первичный ключ
            $table->foreignId('user_id')->nullable()->index(); // Идентификатор пользователя, связанный с сеансом
            $table->string('ip_address', 45)->nullable(); // IP-адрес, с которого был установлен сеанс
            $table->text('user_agent')->nullable(); // Информация о браузере и операционной системе пользователя
            $table->longText('payload'); // Данные сеанса, хранящиеся в сериализованном виде
            $table->integer('last_activity')->index(); // Время последней активности в сеансе
        });
    }

    /**
     * Отмена миграции.
     *
     * Удаляет таблицу сеансов, если она существует.
     *
     * @return void
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');
    }
};
