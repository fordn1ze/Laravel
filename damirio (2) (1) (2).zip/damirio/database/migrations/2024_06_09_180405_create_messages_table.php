<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMessagesTable extends Migration
{
    /**
     * Применение миграции.
     *
     * Создает таблицу для хранения сообщений пользователей.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('messages')) {
            Schema::create('messages', function (Blueprint $table) {
                $table->id(); // Уникальный идентификатор сообщения
                $table->unsignedBigInteger('sender_id')->nullable(); // Идентификатор отправителя сообщения (может быть пустым)
                $table->unsignedBigInteger('recipient_id')->nullable(); // Идентификатор получателя сообщения (может быть пустым)
                $table->text('message'); // Текст сообщения
                $table->unsignedBigInteger('order_id')->nullable(); // Идентификатор заказа, к которому относится сообщение (может быть пустым)
                $table->timestamps(); // Дата и время создания и обновления записи

                // Внешние ключи для связи с таблицами пользователей и заказов
                $table->foreign('sender_id')->references('id')->on('users')->onDelete('set null');
                $table->foreign('recipient_id')->references('id')->on('users')->onDelete('set null');
                $table->foreign('order_id')->references('id')->on('orders')->onDelete('cascade');
            });
        }
    }

    /**
     * Отмена миграции.
     *
     * Удаляет таблицу сообщений, если она существует.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('messages');
    }
}
