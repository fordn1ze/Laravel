<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\RedirectIfAuthenticated;

// Подключение контроллеров для аутентификации
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\AuthLoginController;
use App\Http\Controllers\Auth\AuthLogoutController;

// Подключение контроллера для API, чтобы получить категории новостей
use App\Http\Controllers\Api\GetNewsCategoryController;

// Подключение контроллеров для различных функциональностей приложения
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\ShowOneNewsController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\ShowOneProductController;
use App\Http\Controllers\MakeOrderController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CustomOrderController;

// Маршрут для главной страницы
Route::get('/', [HomeController::class, 'index'])->name('home');

// Маршруты для новостей
Route::get('/news', [NewsController::class, 'index'])->name('news.all');
Route::get('/news/{id}', [ShowOneNewsController::class, 'show']);

// Маршруты для каталога товаров
Route::get('/catalog', [CatalogController::class, 'index']);
Route::get('/catalog/{id}', [ShowOneProductController::class, 'show']);

// Группа маршрутов для API
Route::prefix('api')->group(function () {
    Route::get('/news/categories', [GetNewsCategoryController::class, 'getCategories'])->name('news.categories');
});

// Группа маршрутов для гостей (незарегистрированных пользователей)
Route::middleware('guest')->group(function () {
    Route::post('/register', [RegisterController::class, 'register'])->name('register');
    Route::post('/login', [AuthLoginController::class, 'login'])->name('login');
});

// Группа маршрутов для аутентифицированных пользователей (как для user, так и для admin)
Route::middleware(RedirectIfAuthenticated::class . ':user,admin')->group(function () {
    Route::get('/orders', [OrdersController::class, 'orders'])->name('user.orders');
    Route::post('/orders', [MakeOrderController::class, 'store'])->name('orders.store');
    Route::post('/custom-orders', [CustomOrderController::class, 'store'])->name('custom-orders.store');

    // Маршрут для выхода из системы
    Route::post('/logout', [AuthLogoutController::class, 'logout'])->name('logout');
});

// Группа маршрутов для аутентифицированных администраторов
Route::middleware(RedirectIfAuthenticated::class . ':admin')->group(function () {
    Route::get('/i', [AdminController::class, 'data'])->name('i.data');

    // Подгруппа маршрутов API для администратора
    Route::prefix('api')->group(function () {
        // Действия с пользователями
        Route::post('/admin/user/action/{id}', [AdminController::class, 'userAction'])->name('admin.user.action');

        // Действия с новостями
        Route::post('/admin/news/store', [AdminController::class, 'storeNews'])->name('admin.news.store');
        Route::put('/admin/news/{id}', [AdminController::class, 'updateNews'])->name('admin.news.update');
        Route::delete('/admin/news/delete/{id}', [AdminController::class, 'deleteNews'])->name('admin.news.delete');

        // Действия с продуктами
        Route::post('/admin/products/store', [AdminController::class, 'storeProduct'])->name('admin.products.store');
        Route::put('/admin/products/{id}', [AdminController::class, 'updateProduct'])->name('admin.products.update');
        Route::delete('/admin/product/delete/{id}', [AdminController::class, 'deleteProduct'])->name('admin.product.delete');
    });
});
