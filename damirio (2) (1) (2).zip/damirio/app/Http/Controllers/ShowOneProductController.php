<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowOneProductController extends Controller
{
    public function show($id)
    {
        try {
            $product = Product::findOrFail($id);

            return view('catalog.item.layout', ['product' => $product]);
        } catch (ModelNotFoundException $e) {
            abort(404);
        }
    }
}
