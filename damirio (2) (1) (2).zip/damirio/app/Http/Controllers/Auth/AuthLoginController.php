<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthLoginController extends Controller
{
    public function login(Request $request)
    {
        $rules = [
            'email' => 'required|string|email|max:255',
            'password' => 'required|string|min:6',
        ];

        $customMessages = [
            'email.required' => 'Пожалуйста, введите вашу почту.',
            'email.string' => 'Почта должна быть строкой.',
            'email.email' => 'Введите действительный email адрес.',
            'email.max' => 'Email не может быть длиннее 255 символов.',
            'password.required' => 'Пожалуйста, введите пароль.',
            'password.string' => 'Пароль должен быть строкой.',
            'password.min' => 'Пароль должен быть не менее 6 символов.',
        ];

        $validator = Validator::make($request->all(), $rules, $customMessages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $user = \App\Models\User::where('email', $request->email)->first();

        if (!$user) {
            return back()->withErrors([
                'email' => 'Пользователь с такой почтой не существует.',
            ])->withInput();
        }

        if ($user->role == 'blocked') {
            return back()->withErrors([
                'email' => 'Ваш аккаунт заблокирован.',
            ])->withInput();
        }

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->back();
        }

        return back()->withErrors([
            'password' => 'Неверный пароль.',
        ])->withInput();
    }
}
