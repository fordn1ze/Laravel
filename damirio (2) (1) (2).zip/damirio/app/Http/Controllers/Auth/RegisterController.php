<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Message;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        $rules = [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20|unique:users,phone',
            'address' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email',
            'password' => 'required|string|min:6',
        ];

        $customMessages = [
            'name.required' => 'Пожалуйста, введите ваше имя.',
            'name.string' => 'Имя должно быть строкой.',
            'name.max' => 'Имя не может быть длиннее 255 символов.',
            'phone.required' => 'Пожалуйста, введите ваш телефон.',
            'phone.string' => 'Телефон должен быть строкой.',
            'phone.max' => 'Телефон не может быть длиннее 20 символов.',
            'phone.unique' => 'Этот телефон уже зарегистрирован.',
            'address.required' => 'Пожалуйста, введите ваш адрес.',
            'address.string' => 'Адрес должен быть строкой.',
            'address.max' => 'Адрес не может быть длиннее 255 символов.',
            'email.required' => 'Пожалуйста, введите ваш email.',
            'email.string' => 'Email должен быть строкой.',
            'email.email' => 'Введите действительный email адрес.',
            'email.max' => 'Email не может быть длиннее 255 символов.',
            'email.unique' => 'Этот email уже зарегистрирован.',
            'password.required' => 'Пожалуйста, введите пароль.',
            'password.string' => 'Пароль должен быть строкой.',
            'password.min' => 'Пароль должен быть не менее 6 символов.',
        ];

        $validator = Validator::make($request->all(), $rules, $customMessages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        try {
            $user = User::create([
                'name' => $request->name,
                'phone' => $request->phone,
                'address' => $request->address,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => 'user',
            ]);

            Message::create([
                'sender_id' => null,
                'recipient_id' => $user->id,
                'message' => 'Добро пожаловать, ' . $user->name . '! Если у вас возникнут вопросы, не стесняйтесь обращаться к нам.',
            ]);

            Auth::login($user);

            return redirect()->back();
        } catch (\Exception $e) {
            if ($e instanceof \Illuminate\Database\QueryException && $e->errorInfo[1] == 1062) {
                return redirect()->back()->withErrors(['phone' => 'Этот телефон уже зарегистрирован.'])->withInput();
            }
            return redirect()->back()->withErrors(['error' => 'Ошибка регистрации. Пожалуйста, попробуйте позже.'])->withInput();
        }
    }
}
