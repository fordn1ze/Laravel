<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Order;
use App\Models\Message;
use Exception;

class CustomOrderController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'description' => 'required|string|max:1000',
                'quantity' => 'required|integer|min:1',
            ]);

            $order = new Order();
            $order->user_id = Auth::id();
            $order->quantity = $request->quantity;
            $order->status = 'pending';

            $order->save();

            Message::create([
                'sender_id' => Auth::id(),
                'recipient_id' => 1,
                'order_id' => $order->id,
                'message' => 'Новый заказ: ' . now() . ', Название товара: ' . $request->title . ', Описание: ' . $request->description . ', Количество: ' . $request->quantity . ', Имя пользователя: ' . Auth::user()->name . ', Адрес электронной почты: ' . Auth::user()->email . ', Телефон: ' . Auth::user()->phone . ', Адрес получения: ' . Auth::user()->address
            ]);

            return redirect('/orders');
        } catch (Exception $e) {
            return back();
        }
    }
}
