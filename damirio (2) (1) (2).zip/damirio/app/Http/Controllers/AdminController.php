<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\News;
use App\Models\Product;

class AdminController extends Controller
{
    public function data()
    {
        $users = User::all();
        $news = News::all();
        $products = Product::all();

        return view('admin.layout', compact('users', 'news', 'products'));
    }

    public function userAction(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $action = $request->input('action');

        switch ($action) {
            case 'block':
                $user->role = 'blocked';
                break;
            case 'unblock':
                $user->role = 'user';
                break;
            case 'delete':
                $user->delete();
                return redirect()->back();
            default:
                return redirect()->back();
        }

        $user->save();
        return redirect()->back();
    }

    public function deleteNews($id)
    {
        $news = News::findOrFail($id);
        $news->delete();

        return redirect()->back();
    }

    public function deleteProduct($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();

        return redirect()->back();
    }

    public function storeNews(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'category' => 'required|string|max:255',
            'image_url' => 'required|url|max:255',
        ]);

        News::create([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'category' => $request->input('category'),
            'image_url' => $request->input('image_url'),
        ]);

        return redirect()->back();
    }

    public function storeProduct(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image_url' => 'required|url|max:255',
            'price' => 'required|numeric',
            'shipping_cost' => 'required|numeric',
            'quantity' => 'required|integer',
        ]);

        Product::create([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'image_url' => $request->input('image_url'),
            'price' => $request->input('price'),
            'shipping_cost' => $request->input('shipping_cost'),
            'quantity' => $request->input('quantity'),
        ]);

        return redirect()->back();
    }

    public function updateNews(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'category' => 'required|string|max:255',
            'image_url' => 'required|url|max:255',
        ]);

        $news = News::findOrFail($id);
        $news->title = $request->input('title');
        $news->description = $request->input('description');
        $news->category = $request->input('category');
        $news->image_url = $request->input('image_url');
        $news->save();

        return redirect()->back();
    }


    public function updateProduct(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image_url' => 'required|url|max:255',
            'price' => 'required|numeric',
            'shipping_cost' => 'required|numeric',
            'quantity' => 'required|integer',
        ]);

        $product = Product::findOrFail($id);
        $product->title = $request->input('title');
        $product->description = $request->input('description');
        $product->image_url = $request->input('image_url');
        $product->price = $request->input('price');
        $product->shipping_cost = $request->input('shipping_cost');
        $product->quantity = $request->input('quantity');
        $product->save();

        return redirect()->back();
    }
}
