<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\Order;

class OrdersController extends Controller
{
    public function orders()
    {
        $user = Auth::user();
        $orders = Order::where('user_id', $user->id)->get();
        $totalOrders = $user->orders->count();

        return view('orders.layout', compact('orders', 'totalOrders'));
    }
}
