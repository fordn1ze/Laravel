<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Order;
use App\Models\Product;
use App\Models\Message;
use Exception;

class MakeOrderController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'product_id' => 'required|exists:products,id',
                'quantity' => 'required|integer|min:1',
            ]);

            $product = Product::findOrFail($request->product_id);
            $quantity = $request->quantity;

            if ($product->quantity < $quantity) {
                return back()->withErrors(['Недостаточно товаров на складе.']);
            }

            $order = new Order();
            $order->user_id = Auth::id();
            $order->product_id = $request->product_id;
            $order->quantity = $quantity;
            $order->status = 'pending';
            $order->save();

            $product->quantity -= $quantity;
            $product->save();

            $totalPrice = $product->price * $quantity;
            $totalCost = $totalPrice + $product->shipping_cost;

            Message::create([
                'sender_id' => Auth::id(),
                'recipient_id' => 1,
                'order_id' => $order->id,
                'message' => 'Заказ товара: ' . now() . ', Код товара: ' . $product->id . ', Наименование товара: ' . $product->title . ', Цена товара: ' . $product->price . ', Количество: ' . $quantity . ', Сумма заказа: ' . $totalPrice . ', Стоимость доставки: ' . $product->shipping_cost . ', Общая стоимость: ' . $totalCost . ', Имя пользователя: ' . Auth::user()->name . ', Адрес электронной почты: ' . Auth::user()->email . ', Телефон: ' . Auth::user()->phone . ', Адрес получения: ' . Auth::user()->address
            ]);

            return redirect('/orders');
        } catch (Exception $e) {
            return back();
        }
    }
}
