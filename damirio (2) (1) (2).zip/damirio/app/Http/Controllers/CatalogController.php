<?php

namespace App\Http\Controllers;

use App\Models\Product;

class CatalogController extends Controller
{
    public function index()
    {
        $products = Product::where('quantity', '>', 0)->get();
        $totalQuantity = $products->count();

        return view('catalog.layout', compact('products', 'totalQuantity'));
    }
}
