<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News;

class NewsController extends Controller
{
    public function index(Request $request)
    {
        $categories = $request->input('categories', '');

        if (!empty($categories)) {
            $categoriesArray = explode(',', $categories);
            $allNews = News::whereIn('category', $categoriesArray)
                ->orderBy('created_at', 'desc')
                ->get();
        } else {
            $allNews = News::orderBy('created_at', 'desc')->get();
        }

        $newsCount = $allNews->count();

        if ($request->ajax()) {
            return response()->json(['allNews' => $allNews, 'newsCount' => $newsCount]);
        } else {
            return view('news.layout', compact('allNews', 'newsCount'));
        }
    }
}
