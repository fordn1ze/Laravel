<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\News;

class GetNewsCategoryController extends Controller
{
    public function getCategories()
    {
        $categories = News::pluck('category')->unique()->values();

        return response()->json($categories);
    }
}
