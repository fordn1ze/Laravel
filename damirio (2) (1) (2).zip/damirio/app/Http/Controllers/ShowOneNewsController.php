<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ShowOneNewsController extends Controller
{
    public function show($id)
    {
        try {
            $news = News::findOrFail($id);

            return view('news.item.layout', ['news' => $news]);
        } catch (ModelNotFoundException $e) {
            abort(404);
        }
    }
}
