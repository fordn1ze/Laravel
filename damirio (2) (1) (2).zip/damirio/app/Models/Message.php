<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Модель, представляющая сообщение.
 *
 * @package App\Models
 */
class Message extends Model
{
    use HasFactory;

    /**
     * Массово назначаемые атрибуты.
     *
     * Эти атрибуты могут быть заполнены через методы create и update,
     * либо массово присваиваться значения при создании или обновлении модели.
     *
     * @var array
     */
    protected $fillable = [
        'sender_id',    // ID отправителя сообщения
        'recipient_id', // ID получателя сообщения
        'message',      // Текст сообщения
        'order_id',     // ID заказа, к которому относится сообщение
    ];

    /**
     * Связь "сообщение принадлежит отправителю".
     *
     * Это определение отношения "многие к одному" между сообщением и пользователем,
     * который отправил это сообщение.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sender()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    /**
     * Связь "сообщение принадлежит получателю".
     *
     * Это определение отношения "многие к одному" между сообщением и пользователем,
     * который получил это сообщение.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function recipient()
    {
        return $this->belongsTo(User::class, 'recipient_id');
    }

    /**
     * Связь "сообщение принадлежит заказу".
     *
     * Это определение отношения "многие к одному" между сообщением и заказом,
     * к которому относится это сообщение.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
