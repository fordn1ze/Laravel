<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Модель, представляющая заказ.
 *
 * @package App\Models
 */
class Order extends Model
{
    use HasFactory;

    /**
     * Массово назначаемые атрибуты.
     *
     * Эти атрибуты могут быть заполняемы через методы create и update,
     * либо массово присваиваться значения при создании или обновлении модели.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',    // ID пользователя, сделавшего заказ
        'product_id', // ID продукта, связанного с заказом
        'quantity',   // Количество заказанного продукта
        'status',     // Статус заказа (например, 'pending', 'completed')
    ];

    /**
     * Связь "заказ принадлежит пользователю".
     *
     * Это определение отношения между заказом и пользователем,
     * который сделал этот заказ.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Связь "заказ принадлежит продукту".
     *
     * Это определение отношения между заказом и продуктом,
     * который был заказан.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Связь "заказ имеет одно сообщение".
     *
     * Это определение отношения "один к одному" между заказом и сообщением,
     * связанным с этим заказом.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function message()
    {
        return $this->hasOne(Message::class);
    }
}
