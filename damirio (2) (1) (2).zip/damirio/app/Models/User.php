<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Модель, представляющая пользователя.
 *
 * @package App\Models
 */
class User extends Model implements AuthenticatableContract
{
    use HasFactory, Authenticatable;

    /**
     * Массово назначаемые атрибуты.
     *
     * Эти атрибуты могут быть заполнены через методы create и update,
     * либо массово присваиваться значения при создании или обновлении модели.
     *
     * @var array
     */
    protected $fillable = [
        'name',       // Имя пользователя
        'phone',      // Телефон пользователя
        'email',      // Email пользователя
        'password',   // Пароль пользователя
        'address',    // Адрес пользователя
        'role',       // Роль пользователя (например, 'admin', 'user')
    ];

    /**
     * Скрытые атрибуты.
     *
     * Эти атрибуты будут скрыты при сериализации модели,
     * например, при преобразовании модели в массив или JSON.
     *
     * @var array
     */
    protected $hidden = [
        'password',          // Пароль пользователя
        'remember_token',    // Токен для запоминания пользователя
    ];

    /**
     * Связь "пользователь имеет много заказов".
     *
     * Это определение отношения "один ко многим" между пользователем и заказами,
     * которые он сделал.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Связь "пользователь отправил много сообщений".
     *
     * Это определение отношения "один ко многим" между пользователем и сообщениями,
     * которые он отправил.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sentMessages()
    {
        return $this->hasMany(Message::class, 'sender_id');
    }

    /**
     * Связь "пользователь получил много сообщений".
     *
     * Это определение отношения "один ко многим" между пользователем и сообщениями,
     * которые он получил.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function receivedMessages()
    {
        return $this->hasMany(Message::class, 'recipient_id');
    }
}
