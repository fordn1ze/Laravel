<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Модель, представляющая новостную запись.
 *
 * @package App\Models
 */
class News extends Model
{
    use HasFactory;

    /**
     * Массово назначаемые атрибуты.
     *
     * Эти атрибуты можно заполнять через методы create и update,
     * либо массово присваивать значения при создании или обновлении модели.
     *
     * @var array
     */
    protected $fillable = [
        'title',       // Заголовок новости
        'description', // Описание новости
        'category',    // Категория новости
        'image_url',   // URL изображения, связанного с новостью
    ];
}
