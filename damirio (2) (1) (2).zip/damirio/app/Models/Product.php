<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Модель, представляющая продукт.
 *
 * @package App\Models
 */
class Product extends Model
{
    use HasFactory;

    /**
     * Массово назначаемые атрибуты.
     *
     * Эти атрибуты могут быть заполняемы через методы create и update,
     * либо массово присваиваться значения при создании или обновлении модели.
     *
     * @var array
     */
    protected $fillable = [
        'title',          // Заголовок продукта
        'description',    // Описание продукта
        'price',          // Цена продукта
        'shipping_cost',  // Стоимость доставки продукта
        'quantity',       // Количество доступного продукта
        'image_url',      // URL изображения продукта
    ];

    /**
     * Связь "продукт имеет много заказов".
     *
     * Это определение отношения "один ко многим" между продуктом и заказами,
     * связанными с этим продуктом.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }
}
