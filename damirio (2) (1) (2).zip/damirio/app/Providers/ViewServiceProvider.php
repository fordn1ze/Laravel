<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Auth;
use App\Models\Message;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     * Здесь вы можете регистрировать любые сервисы.
     * Этот метод оставлен пустым, так как в этом случае ничего не нужно регистрировать.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     * Этот метод выполняется после того, как все сервисы были зарегистрированы.
     * Он используется для выполнения любых действий, необходимых для "загрузки" сервиса.
     */
    public function boot(): void
    {
        // Используем видовой композер для передачи сообщений во все представления
        View::composer('*', function ($view) {
            // Проверяем, авторизован ли пользователь
            if (Auth::check()) {
                // Получаем текущего авторизованного пользователя
                $user = Auth::user();

                // Получаем сообщения, где текущий пользователь является либо получателем, либо отправителем
                $messages = Message::where('recipient_id', $user->id)
                    ->orWhere('sender_id', $user->id)
                    ->orderBy('created_at', 'asc')
                    ->get();

                // Передаем сообщения во все представления
                $view->with('messages', $messages);
            }
        });
    }
}
