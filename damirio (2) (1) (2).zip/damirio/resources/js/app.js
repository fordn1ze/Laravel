/* подключение библиотек preline и bootstrap к проекту */
import "preline";
import "./bootstrap";
