<div class="flex flex-row items-center justify-between gap-4 flex-wrap bg-white border border-gray-200 shadow-sm rounded-xl p-4 md:p-5 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400">
    <h3 id="newsCountContainer" class="text-2xl font-semibold text-gray-800 dark:text-white">
        Всего заказов: {{ $totalOrders }}
    </h3>
</div>

<div id="newsContentContainer" class="grid grid-cols-1 lg:gap-y-16 gap-10 mt-10">
    @if($orders->isEmpty())
    <div class="flex flex-col gap-4 items-center justify-center mt-20">
        <p class="text-xl font-semibold text-gray-800 dark:text-white">
            Вы ещё ничего не заказывали...
        </p>
        <a href="/catalog" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
            Перейти к покупкам
        </a>
    </div>
    @else
    @foreach($orders as $order)
    @if(isset($order->product->id))
    <a class="group rounded-xl overflow-hidden" href="/catalog/{{ $order->product->id }}">
        <div class="sm:flex sm:items-center">
            <div class="flex-shrink-0 relative rounded-xl overflow-hidden w-full sm:w-56 h-44">
                <img class="group-hover:scale-105 transition-transform duration-500 ease-in-out size-full absolute top-0 start-0 object-cover rounded-xl" src="{{ $order->product->image_url }}" alt="{{ $order->product->title }}">
            </div>
            <div class="grow mt-4 sm:mt-0 sm:ms-6 px-4 sm:px-0">
                <h3 class="text-xl font-semibold text-gray-800 group-hover:text-gray-600 dark:text-neutral-300 dark:group-hover:text-white line-clamp-1">
                    {{ $order->product->title }}
                </h3>
                <p class="mt-3 text-gray-600 dark:text-neutral-400 line-clamp-3">
                    {{ $order->product->description }}
                </p>
                <div class="flex flex-row gap-2 items-center justify-between mt-4">
                    <p class="inline-flex items-center gap-x-1 text-blue-600 decoration-2 hover:underline font-medium">
                        Подробнее
                        <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m9 18 6-6-6-6" />
                        </svg>
                    </p>
                </div>
            </div>
            <div class="px-4 flex flex-col sm:items-end sm:text-end w-full">
                <p class="mt-2 text-white">
                    Цена за единицу: {{ $order->product->price }} ₽
                </p>
                <p class="text-white">
                    Количество: {{ $order->quantity }}
                </p>
                <p class="text-white">
                    Стоимость доставки: {{ $order->product->shipping_cost }} ₽
                </p>
                <p class="text-white">
                    Общая стоимость: {{ $order->quantity * $order->product->price + $order->product->shipping_cost }} ₽
                </p>
            </div>
        </div>
    </a>
    @endif
    @endforeach
    @endif
</div>