<div class="px-4 pb-12 sm:px-6 lg:px-8 mx-auto">
    <div class="space-y-5 md:space-y-8">
        <div class="space-y-3">
            <div class="flex flex-row items-center gap-4 justify-between">
                <h2 class="text-2xl font-bold md:text-3xl dark:text-white">{{ $product->title }}</h2>
                <span class="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xl font-medium bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-500">Цена: {{ $product->price }} ₽</span>
            </div>
            <p class="text-lg text-gray-800 dark:text-neutral-200"> {{ $product->description }}</p>
        </div>
        <figure>
            <img class="w-full object-cover rounded-xl max-h-[400px]" src="{{ $product->image_url }}" alt="{{ $product->title }}">
            <figcaption class="mt-3 text-sm text-center text-gray-500 dark:text-neutral-500">
                На складе: {{ $product->quantity }} шт.
            </figcaption>
        </figure>
        <form action="{{ route('orders.store') }}" method="POST">
            @csrf
            <input type="hidden" name="product_id" value="{{ $product->id }}">
            <div class="flex rounded-lg shadow-sm border border-blue-600">
                <span class="px-4 inline-flex items-center min-w-fit rounded-s-md border border-e-0 border-gray-200 bg-gray-50 text-sm text-gray-500 dark:bg-neutral-700 dark:border-neutral-700 dark:text-neutral-400">Количество заказываемых товаров:</span>
                <input name="quantity" type="number" id="hs-search-box-with-loading-3" class="py-3 px-4 block w-full border-gray-200 shadow-sm rounded-0 text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600" value="1" max="{{ $product->quantity }}" placeholder="Введите число нужных вам товаров" @if($product->quantity <= 0 || !auth()->check()) disabled @endif>
                <button type="submit" class="py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-e-md border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none" @if($product->quantity <= 0 || !auth()->check()) disabled @endif>
                        Заказать
                </button>
            </div>
        </form>
        @if ($errors->any())
        <div class="flex flex-col gap-2 mb-4">
            @foreach ($errors->all() as $error)
            <div class="inline-flex items-center">
                <span class="size-2 inline-block bg-red-500 rounded-full me-2"></span>
                <span class="text-gray-600 dark:text-neutral-400">{{ $error }}</span>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
