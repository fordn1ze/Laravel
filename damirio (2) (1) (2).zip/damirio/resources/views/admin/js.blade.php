<script>
    document.addEventListener('DOMContentLoaded', function() {
        const changeNewsButtons = document.querySelectorAll('button[data-news-id]');
        const changeProductButtons = document.querySelectorAll('button[data-product-id]');

        changeNewsButtons.forEach(button => {
            button.addEventListener('click', function() {
                const newsId = this.getAttribute('data-news-id');
                const newsTitle = this.getAttribute('data-news-title');
                const newsDescription = this.getAttribute('data-news-description');
                const newsCategory = this.getAttribute('data-news-category');
                const newsImageUrl = this.getAttribute('data-news-image-url');

                document.getElementById('change-news_id').value = newsId;
                document.getElementById('change-title').value = newsTitle;
                document.getElementById('change-description').value = newsDescription;
                document.getElementById('change-category').value = newsCategory;
                document.getElementById('change-image_url').value = newsImageUrl;

                const formAction = "{{ route('admin.news.update', ':newsId') }}".replace(':newsId', newsId);
                document.getElementById('change-news').setAttribute('action', formAction);
            });
        });

        changeProductButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                const productTitle = this.getAttribute('data-product-title');
                const productDescription = this.getAttribute('data-product-description');
                const productImageUrl = this.getAttribute('data-product-image-url');
                const productPrice = this.getAttribute('data-product-price');
                const productShippingCost = this.getAttribute('data-product-shipping-cost');
                const productQuantity = this.getAttribute('data-product-quantity');

                document.getElementById('change-product_id').value = productId;
                document.getElementById('change-product-title').value = productTitle;
                document.getElementById('change-product-description').value = productDescription;
                document.getElementById('change-product-image_url').value = productImageUrl;
                document.getElementById('change-product-price').value = productPrice;
                document.getElementById('change-product-shipping_cost').value = productShippingCost;
                document.getElementById('change-product-quantity').value = productQuantity;

                const formAction = "{{ route('admin.products.update', ':productId') }}".replace(':productId', productId);
                document.getElementById('change-product').setAttribute('action', formAction);
            });
        });
    });
</script>