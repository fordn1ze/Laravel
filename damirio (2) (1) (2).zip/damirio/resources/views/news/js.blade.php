<script>
    window.addEventListener('load', () => requestAnimationFrame(() => {
        const selectElement = document.querySelector('#newsCategorySelect');
        const select = window.HSSelect.getInstance(selectElement);

        fetch('/api/news/categories')
            .then(response => response.json())
            .then(data => {
                if (data.length === 0) {
                    select.addOption({
                        title: "Нет доступных категорий новостей",
                        val: ""
                    });
                } else {
                    data.forEach(category => {
                        select.addOption({
                            title: category,
                            val: category,
                        });
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching news categories:', error);
            });

        select.on('change', function(val) {
            const selectedCategories = Array.from(selectElement.selectedOptions).map(option => option.value);
            const queryString = selectedCategories.length ? `?categories=${selectedCategories.join(',')}` : '';

            fetch(`/news${queryString}`)
                .then(response => response.text())
                .then(html => {
                    // Создание временного контейнера для парсинга HTML-кода
                    const tempContainer = document.createElement('div');
                    tempContainer.innerHTML = html;

                    // Выбор только нужных элементов из временного контейнера
                    const newsItems = tempContainer.querySelectorAll('.news-item');

                    // Получение контейнера, куда будут вставлены новости
                    const newsContainer = document.getElementById('newsContentContainer');

                    const newsCount = tempContainer.querySelectorAll('.news-item').length;

                    document.getElementById('newsCountContainer').innerText = `Всего новостей: ${newsCount}`;

                    // Очистка контейнера перед вставкой новых элементов
                    newsContainer.innerHTML = '';

                    // Вставка выбранных новостей в контейнер
                    newsItems.forEach(newsItem => {
                        newsContainer.appendChild(newsItem);
                    });
                })
                .catch(error => {
                    console.error('Error fetching news content:', error);
                });
        });
    }));
</script>