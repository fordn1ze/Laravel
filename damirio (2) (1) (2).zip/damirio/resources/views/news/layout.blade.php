<!DOCTYPE html>
<html class="scroll-smooth dark" lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Damirio новости</title>

    @vite('resources/css/app.css')
</head>

<body class="bg-neutral-900">
    @include('news.header')

    <main class="max-w-[1440px] mx-auto px-[4vw] mb-8 mt-[70px]">
        @include('news.page')
    </main>

    @if(!auth()->check())
    @include('components.auth.modal')
    @endif

    @vite('resources/js/app.js')
</body>

</html>