<div class="px-4 pb-12 sm:px-6 lg:px-8 mx-auto">
    <div class="space-y-5 md:space-y-8">
        <div class="space-y-3">
            <div class="flex flex-row items-center gap-4 justify-between">
                <h2 class="text-2xl font-bold md:text-3xl dark:text-white">{{ $news->title }}</h2>
                <span class="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-500">{{ $news->category }}</span>
            </div>
            <p class="text-lg text-gray-800 dark:text-neutral-200"> {{ $news->description }}</p>
        </div>
        <figure>
            <img class="w-full object-cover rounded-xl max-h-[500px]" src="{{ $news->image_url }}" alt="{{ $news->title }}">
            <figcaption class="mt-3 text-sm text-center text-gray-500 dark:text-neutral-500">
                {{ $news->created_at->format('d.m.Y') }}
            </figcaption>
        </figure>
    </div>
</div>